import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles/theme.css';

const container = document.getElementById('root');
if (!container) {
    throw new Error('root element not found');
}

createRoot(container).render(
    <StrictMode>
        <App />
    </StrictMode>
);
